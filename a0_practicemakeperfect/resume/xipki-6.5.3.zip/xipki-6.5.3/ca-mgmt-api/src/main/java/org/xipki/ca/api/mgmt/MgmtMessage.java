// Copyright (c) 2013-2024 xipki. All rights reserved.
// License Apache License 2.0

package org.xipki.ca.api.mgmt;

/**
 * CA Management message via the REST API.
 *
 * @author Lijun Liao (xipki)
 */

public abstract class MgmtMessage {

}
