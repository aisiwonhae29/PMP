Deployment in Tomcat (8, 9 and 10)
----
1. Execute the command  
   `./install.sh -t <tomcat dir of HSM proxy server>`
