## Restore the setup package
- Execute `./restore.sh <dest-dir>` where `<dest-dir>` is the destination dir of the restored package.
- Follow the `<dest-dir>/INSTALL.md`.
